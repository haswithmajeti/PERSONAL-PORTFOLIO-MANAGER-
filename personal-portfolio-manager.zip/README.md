# PortfolioPulse — Personal Portfolio Manager

A modern, responsive, and feature-packed web application for managing and tracking your personal investment portfolio (Stocks, Crypto, ETFs, Real Estate, Cash, Commodities).

## 🚀 Key Features

- **Executive KPI Dashboard**: Real-time Net Worth, Total Invested Capital, Total Unrealized Gain/Loss ($ and %), and Top Performing Asset.
- **Dynamic Asset Allocation Chart**: Interactive Doughnut chart (via Chart.js) visualizing your holdings across asset classes.
- **Growth & Net Worth Timeline**: Historical performance trend line chart with switchable horizons (`6M`, `1Y`, `ALL`).
- **Holdings Management (CRUD)**:
  - Add, edit, and delete positions.
  - Automatically calculates invested capital, current market value, profit/loss, and ROI %.
- **Filter & Search**:
  - Filter by asset categories (*Stocks, Crypto, ETFs, Real Estate, Cash, Commodities*).
  - Instant live search by asset name or ticker symbol.
- **Persistence & Portability**:
  - Automatically saves all your data to your browser's `localStorage`.
  - **Export to JSON**: Backup your entire portfolio with one click.
  - **Import from JSON**: Restore or transfer your portfolio data anytime.
  - Reset to default sample data button.
- **Sleek Dark Theme UI**: Built with Tailwind CSS and Lucide Icons.

---

## 💻 How to Run

### Option 1: Open Directly (Zero Installation)
Simply double-click `index.html` or right-click and open it in any modern web browser (Chrome, Edge, Firefox, Brave, Safari).

### Option 2: Run with a Local Web Server
You can launch a lightweight local HTTP server using Python or Node.js:

```powershell
# Using Python
python -m http.server 3000

# Or using Node / npx
npx serve .
```
Then navigate to `http://localhost:3000` in your browser.

---

## 🔌 Connecting to Live Stock & Crypto APIs (Optional Next Step)

Currently, current prices are stored locally and can be manually updated in the edit modal. To fetch real-time market prices automatically:

1. **Crypto Prices**: Use the free CoinGecko API:
   ```javascript
   const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd');
   const data = await res.json();
   ```
2. **Stock & ETF Prices**: Use free API keys from:
   - [Alpha Vantage](https://www.alphavantage.co/)
   - [Finnhub](https://finnhub.io/)
   - [Yahoo Finance (via RapidAPI)](https://rapidapi.com/)

---

## 📁 File Structure

```text
personal-portfolio-manager/
├── index.html       # Main UI dashboard and modals
├── styles.css       # Custom animations and category badges
├── app.js           # Calculations, Chart.js integrations, storage engine
└── README.md        # Documentation and guide
```
