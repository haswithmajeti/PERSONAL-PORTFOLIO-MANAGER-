// PortfolioPulse - Personal Portfolio Manager
// State & Storage Logic

const STORAGE_KEY = 'portfoliopulse_assets_v1';

// Initial realistic sample data
const DEFAULT_ASSETS = [
  { id: '1', name: 'Apple Inc.', ticker: 'AAPL', category: 'Stocks', quantity: 35, buyPrice: 155.00, currentPrice: 228.40 },
  { id: '2', name: 'Microsoft Corp.', ticker: 'MSFT', category: 'Stocks', quantity: 20, buyPrice: 320.00, currentPrice: 418.50 },
  { id: '3', name: 'Nvidia Corp.', ticker: 'NVDA', category: 'Stocks', quantity: 45, buyPrice: 85.00, currentPrice: 132.80 },
  { id: '4', name: 'Bitcoin', ticker: 'BTC', category: 'Crypto', quantity: 0.45, buyPrice: 44000.00, currentPrice: 89200.00 },
  { id: '5', name: 'Ethereum', ticker: 'ETH', category: 'Crypto', quantity: 3.5, buyPrice: 2200.00, currentPrice: 3340.00 },
  { id: '6', name: 'Vanguard S&P 500 ETF', ticker: 'VOO', category: 'ETF', quantity: 40, buyPrice: 410.00, currentPrice: 545.20 },
  { id: '7', name: 'Realty Income REIT', ticker: 'O', category: 'Real Estate', quantity: 150, buyPrice: 52.00, currentPrice: 55.40 },
  { id: '8', name: 'High Yield Cash Reserve', ticker: 'USD', category: 'Cash', quantity: 1, buyPrice: 12500.00, currentPrice: 12500.00 }
];

let assets = [];
let activeCategoryFilter = 'ALL';
let searchQuery = '';
let activeTimeRange = '6M';
let allocationChartInstance = null;
let growthChartInstance = null;

// Category Color Palette
const CATEGORY_COLORS = {
  'Stocks': '#3b82f6',
  'Crypto': '#a855f7',
  'ETF': '#14b8a6',
  'Real Estate': '#eab308',
  'Cash': '#64748b',
  'Commodities': '#f97316'
};

// Formatting Utilities
function formatCurrency(num) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(num);
}

function formatPercent(num) {
  const prefix = num > 0 ? '+' : '';
  return `${prefix}${num.toFixed(2)}%`;
}

function formatNumber(num, maxDecimals = 4) {
  return Number(num).toLocaleString('en-US', {
    maximumFractionDigits: maxDecimals
  });
}

// Storage Operations
function loadAssets() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      assets = JSON.parse(raw);
    } else {
      assets = JSON.parse(JSON.stringify(DEFAULT_ASSETS));
      saveAssets();
    }
  } catch (err) {
    console.error('Failed to parse assets from localStorage:', err);
    assets = JSON.parse(JSON.stringify(DEFAULT_ASSETS));
  }
}

function saveAssets() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(assets));
}

// Calculation Engine
function calculateMetrics() {
  let totalNetWorth = 0;
  let totalInvested = 0;
  let bestPerformer = null;
  let highestRoi = -Infinity;

  const enrichedAssets = assets.map(asset => {
    const qty = parseFloat(asset.quantity) || 0;
    const buy = parseFloat(asset.buyPrice) || 0;
    const cur = parseFloat(asset.currentPrice) || 0;

    const invested = qty * buy;
    const marketValue = qty * cur;
    const pnl = marketValue - invested;
    const pnlPercent = invested > 0 ? (pnl / invested) * 100 : 0;

    totalNetWorth += marketValue;
    totalInvested += invested;

    if (pnlPercent > highestRoi) {
      highestRoi = pnlPercent;
      bestPerformer = { ...asset, pnlPercent };
    }

    return {
      ...asset,
      qty,
      buy,
      cur,
      invested,
      marketValue,
      pnl,
      pnlPercent
    };
  });

  const totalPnl = totalNetWorth - totalInvested;
  const totalPnlPercent = totalInvested > 0 ? (totalPnl / totalInvested) * 100 : 0;

  return {
    totalNetWorth,
    totalInvested,
    totalPnl,
    totalPnlPercent,
    bestPerformer,
    enrichedAssets
  };
}

// Render Top KPI Cards
function renderKPIs(metrics) {
  document.getElementById('statNetWorth').textContent = formatCurrency(metrics.totalNetWorth);
  document.getElementById('statInvested').textContent = formatCurrency(metrics.totalInvested);
  document.getElementById('statAssetsCount').textContent = assets.length;

  // Net worth badge
  const badge = document.getElementById('statNetWorthBadge');
  const isGain = metrics.totalPnl >= 0;
  badge.className = `inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-semibold ${
    isGain ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
  }`;
  badge.innerHTML = `<i data-lucide="${isGain ? 'trending-up' : 'trending-down'}" class="w-3.5 h-3.5"></i> <span>${formatPercent(metrics.totalPnlPercent)}</span>`;

  // Total Gain / Loss
  const pnlEl = document.getElementById('statTotalPnl');
  const pnlIconEl = document.getElementById('statPnlIconContainer');
  pnlEl.textContent = (metrics.totalPnl >= 0 ? '+' : '') + formatCurrency(metrics.totalPnl);
  pnlEl.className = `text-2xl lg:text-3xl font-extrabold mt-1 tracking-tight ${
    metrics.totalPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
  }`;
  pnlIconEl.className = `p-2.5 rounded-xl border ${
    metrics.totalPnl >= 0
      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  }`;
  pnlIconEl.innerHTML = `<i data-lucide="${metrics.totalPnl >= 0 ? 'arrow-up-right' : 'arrow-down-right'}" class="w-5 h-5"></i>`;

  // Best Performer
  const topPerfEl = document.getElementById('statTopPerformer');
  const topPerfReturnEl = document.getElementById('statTopPerformerReturn');
  if (metrics.bestPerformer) {
    topPerfEl.textContent = `${metrics.bestPerformer.ticker}`;
    topPerfReturnEl.textContent = formatPercent(metrics.bestPerformer.pnlPercent);
    topPerfReturnEl.className = metrics.bestPerformer.pnlPercent >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold';
  } else {
    topPerfEl.textContent = 'None';
    topPerfReturnEl.textContent = '+0.00%';
  }
}

// Render Holdings Table
function renderTable(enrichedAssets) {
  const tbody = document.getElementById('holdingsTableBody');
  const emptyState = document.getElementById('emptyState');
  const countDisplay = document.getElementById('tableCountDisplay');

  // Filter based on active category & search query
  const filtered = enrichedAssets.filter(item => {
    const matchesCategory = activeCategoryFilter === 'ALL' || item.category.toLowerCase() === activeCategoryFilter.toLowerCase();
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch = !query || 
      item.name.toLowerCase().includes(query) || 
      item.ticker.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });

  countDisplay.textContent = `Showing ${filtered.length} of ${assets.length} holdings`;

  if (filtered.length === 0) {
    tbody.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');

  const rowsHtml = filtered.map(item => {
    const categoryClass = `badge-${item.category.toLowerCase().replace(/\s+/g, '-')}`;
    const isProfitable = item.pnl >= 0;
    const pnlColor = isProfitable ? 'text-emerald-400' : 'text-rose-400';

    return `
      <tr class="hover:bg-slate-800/40 transition-colors group">
        <td class="py-3.5 px-5">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/80 flex items-center justify-center font-bold text-xs text-indigo-300">
              ${item.ticker.substring(0, 3).toUpperCase()}
            </div>
            <div>
              <div class="font-bold text-white group-hover:text-indigo-400 transition">${escapeHtml(item.name)}</div>
              <div class="text-xs text-slate-400 font-mono">${escapeHtml(item.ticker)}</div>
            </div>
          </div>
        </td>
        <td class="py-3.5 px-4">
          <span class="inline-block px-2.5 py-0.5 rounded-md text-xs font-semibold ${categoryClass}">
            ${escapeHtml(item.category)}
          </span>
        </td>
        <td class="py-3.5 px-4 text-right font-mono text-slate-200">
          ${formatNumber(item.qty)}
        </td>
        <td class="py-3.5 px-4 text-right font-mono text-slate-300">
          ${formatCurrency(item.buy)}
        </td>
        <td class="py-3.5 px-4 text-right font-mono text-slate-100 font-semibold">
          ${formatCurrency(item.cur)}
        </td>
        <td class="py-3.5 px-4 text-right font-mono text-white font-bold">
          ${formatCurrency(item.marketValue)}
        </td>
        <td class="py-3.5 px-4 text-right">
          <div class="font-mono font-semibold ${pnlColor}">
            ${(isProfitable ? '+' : '') + formatCurrency(item.pnl)}
          </div>
          <div class="text-[11px] font-mono ${pnlColor}">
            ${formatPercent(item.pnlPercent)}
          </div>
        </td>
        <td class="py-3.5 px-5 text-center">
          <div class="flex items-center justify-center gap-1.5">
            <button onclick="openEditModal('${item.id}')" title="Edit" class="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition">
              <i data-lucide="edit-3" class="w-4 h-4"></i>
            </button>
            <button onclick="deleteAsset('${item.id}')" title="Delete" class="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition">
              <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  tbody.innerHTML = rowsHtml;
}

// Render Allocation Chart
function renderAllocationChart(enrichedAssets) {
  const categoryTotals = {};
  enrichedAssets.forEach(item => {
    categoryTotals[item.category] = (categoryTotals[item.category] || 0) + item.marketValue;
  });

  const labels = Object.keys(categoryTotals);
  const data = Object.values(categoryTotals);
  const totalValue = data.reduce((a, b) => a + b, 0);

  const backgroundColors = labels.map(lbl => CATEGORY_COLORS[lbl] || '#6366f1');

  // Update Legend UI
  const legendContainer = document.getElementById('allocationLegend');
  legendContainer.innerHTML = labels.map((lbl, idx) => {
    const val = data[idx];
    const pct = totalValue > 0 ? ((val / totalValue) * 100).toFixed(1) : 0;
    return `
      <div class="flex items-center justify-between p-1.5 rounded bg-slate-950/60 border border-slate-800/60">
        <div class="flex items-center gap-2 truncate">
          <span class="w-2.5 h-2.5 rounded-full flex-shrink-0" style="background-color: ${backgroundColors[idx]}"></span>
          <span class="text-slate-300 truncate">${lbl}</span>
        </div>
        <span class="font-mono text-slate-400 font-semibold ml-2">${pct}%</span>
      </div>
    `;
  }).join('');

  const ctx = document.getElementById('allocationChart').getContext('2d');

  if (allocationChartInstance) {
    allocationChartInstance.destroy();
  }

  allocationChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: backgroundColors,
        borderColor: '#0f172a',
        borderWidth: 2,
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#090d16',
          titleColor: '#f8fafc',
          bodyColor: '#cbd5e1',
          borderColor: '#1e293b',
          borderWidth: 1,
          padding: 10,
          callbacks: {
            label: function(context) {
              const val = context.raw || 0;
              const pct = totalValue > 0 ? ((val / totalValue) * 100).toFixed(1) : 0;
              return ` ${context.label}: ${formatCurrency(val)} (${pct}%)`;
            }
          }
        }
      },
      cutout: '72%'
    }
  });
}

// Render Growth Trend Chart (Historical Timeline)
function renderGrowthChart(currentNetWorth) {
  const ctx = document.getElementById('growthChart').getContext('2d');

  // Generate simulated historical trend curve reaching current Net Worth
  let labels = [];
  let points = [];

  if (activeTimeRange === '6M') {
    labels = ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
    const multipliers = [0.82, 0.86, 0.84, 0.91, 0.94, 0.97, 1.0];
    points = multipliers.map(m => currentNetWorth * m);
  } else if (activeTimeRange === '1Y') {
    labels = ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
    const multipliers = [0.72, 0.75, 0.78, 0.81, 0.79, 0.85, 0.88, 0.90, 0.93, 0.92, 0.96, 1.0];
    points = multipliers.map(m => currentNetWorth * m);
  } else {
    // ALL (3-year horizon)
    labels = ['2023 Q1', '2023 Q3', '2024 Q1', '2024 Q3', '2025 Q1', '2025 Q3', '2026 Q2', 'Current'];
    const multipliers = [0.45, 0.52, 0.60, 0.68, 0.75, 0.84, 0.93, 1.0];
    points = multipliers.map(m => currentNetWorth * m);
  }

  if (growthChartInstance) {
    growthChartInstance.destroy();
  }

  // Create gradient
  const gradient = ctx.createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, 'rgba(99, 102, 241, 0.35)');
  gradient.addColorStop(1, 'rgba(99, 102, 241, 0.0)');

  growthChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Portfolio Value',
        data: points,
        borderColor: '#6366f1',
        borderWidth: 2.5,
        backgroundColor: gradient,
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#818cf8',
        pointBorderColor: '#0f172a',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#090d16',
          titleColor: '#f8fafc',
          bodyColor: '#cbd5e1',
          borderColor: '#1e293b',
          borderWidth: 1,
          padding: 10,
          callbacks: {
            label: function(context) {
              return ` Net Worth: ${formatCurrency(context.raw)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false, color: '#1e293b' },
          ticks: { color: '#64748b', font: { size: 11 } }
        },
        y: {
          grid: { color: '#1e293b' },
          ticks: {
            color: '#64748b',
            font: { size: 11 },
            callback: function(val) {
              if (val >= 1000) return '$' + (val / 1000).toFixed(0) + 'k';
              return '$' + val;
            }
          }
        }
      }
    }
  });
}

// Master Render Function
function updateUI() {
  const metrics = calculateMetrics();
  renderKPIs(metrics);
  renderTable(metrics.enrichedAssets);
  renderAllocationChart(metrics.enrichedAssets);
  renderGrowthChart(metrics.totalNetWorth);
  
  if (window.lucide) {
    lucide.createIcons();
  }
}

// Modal Handlers
const modal = document.getElementById('assetModal');
const assetForm = document.getElementById('assetForm');
const modalTitle = document.getElementById('modalTitle');

function openAddModal() {
  modalTitle.textContent = 'Add New Asset';
  assetForm.reset();
  document.getElementById('assetId').value = '';
  modal.classList.remove('hidden');
  document.getElementById('assetName').focus();
}

function openEditModal(id) {
  const asset = assets.find(a => a.id === id);
  if (!asset) return;

  modalTitle.textContent = 'Edit Asset';
  document.getElementById('assetId').value = asset.id;
  document.getElementById('assetName').value = asset.name;
  document.getElementById('assetTicker').value = asset.ticker;
  document.getElementById('assetCategory').value = asset.category;
  document.getElementById('assetQuantity').value = asset.quantity;
  document.getElementById('assetBuyPrice').value = asset.buyPrice;
  document.getElementById('assetCurrentPrice').value = asset.currentPrice;

  modal.classList.remove('hidden');
}

function closeModal() {
  modal.classList.add('hidden');
  assetForm.reset();
}

function deleteAsset(id) {
  const asset = assets.find(a => a.id === id);
  if (!asset) return;
  
  if (confirm(`Are you sure you want to remove ${asset.name} (${asset.ticker}) from your portfolio?`)) {
    assets = assets.filter(a => a.id !== id);
    saveAssets();
    updateUI();
  }
}

// Save Asset Form Submit
assetForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const id = document.getElementById('assetId').value;
  const name = document.getElementById('assetName').value.trim();
  const ticker = document.getElementById('assetTicker').value.trim().toUpperCase();
  const category = document.getElementById('assetCategory').value;
  const quantity = parseFloat(document.getElementById('assetQuantity').value);
  const buyPrice = parseFloat(document.getElementById('assetBuyPrice').value);
  const currentPrice = parseFloat(document.getElementById('assetCurrentPrice').value);

  if (!name || !ticker || isNaN(quantity) || isNaN(buyPrice) || isNaN(currentPrice)) {
    alert('Please fill out all fields with valid numbers.');
    return;
  }

  if (id) {
    // Edit existing
    const index = assets.findIndex(a => a.id === id);
    if (index !== -1) {
      assets[index] = { id, name, ticker, category, quantity, buyPrice, currentPrice };
    }
  } else {
    // Add new
    const newAsset = {
      id: Date.now().toString(),
      name,
      ticker,
      category,
      quantity,
      buyPrice,
      currentPrice
    };
    assets.push(newAsset);
  }

  saveAssets();
  closeModal();
  updateUI();
});

// Category Filter Pills
document.querySelectorAll('.category-pill').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.category-pill').forEach(b => {
      b.classList.remove('bg-indigo-600', 'text-white');
      b.classList.add('text-slate-400');
    });
    btn.classList.remove('text-slate-400');
    btn.classList.add('bg-indigo-600', 'text-white');

    activeCategoryFilter = btn.getAttribute('data-category');
    const metrics = calculateMetrics();
    renderTable(metrics.enrichedAssets);
    if (window.lucide) lucide.createIcons();
  });
});

// Time Range Filter Buttons
document.querySelectorAll('.time-filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.time-filter-btn').forEach(b => {
      b.classList.remove('bg-indigo-600', 'text-white');
      b.classList.add('text-slate-400');
    });
    btn.classList.remove('text-slate-400');
    btn.classList.add('bg-indigo-600', 'text-white');

    activeTimeRange = btn.getAttribute('data-range');
    const metrics = calculateMetrics();
    renderGrowthChart(metrics.totalNetWorth);
  });
});

// Search Input Listener
document.getElementById('searchInput').addEventListener('input', (e) => {
  searchQuery = e.target.value;
  const metrics = calculateMetrics();
  renderTable(metrics.enrichedAssets);
  if (window.lucide) lucide.createIcons();
});

// Export Data as JSON
document.getElementById('exportBtn').addEventListener('click', () => {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(assets, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `portfolio_backup_${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
});

// Import Data from JSON
const importFileInput = document.getElementById('importFileInput');
document.getElementById('importBtn').addEventListener('click', () => {
  importFileInput.click();
});

importFileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const parsed = JSON.parse(event.target.result);
      if (Array.isArray(parsed)) {
        assets = parsed;
        saveAssets();
        updateUI();
        alert('Portfolio data imported successfully!');
      } else {
        alert('Invalid JSON file format: Expected an array of assets.');
      }
    } catch (err) {
      alert('Error parsing JSON file: ' + err.message);
    }
  };
  reader.readAsText(file);
  importFileInput.value = '';
});

// Reset Sample Data
document.getElementById('resetDemoDataBtn').addEventListener('click', () => {
  if (confirm('Reset your portfolio back to default sample assets? Any custom assets will be overwritten.')) {
    assets = JSON.parse(JSON.stringify(DEFAULT_ASSETS));
    saveAssets();
    updateUI();
  }
});

// Modal toggle event listeners
document.getElementById('openAddAssetModalBtn').addEventListener('click', openAddModal);
document.getElementById('closeModalBtn').addEventListener('click', closeModal);
document.getElementById('cancelModalBtn').addEventListener('click', closeModal);

// Close modal when clicking outside box
modal.addEventListener('click', (e) => {
  if (e.target === modal) {
    closeModal();
  }
});

// Escape HTML utility to prevent XSS
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Initial bootstrap
window.addEventListener('DOMContentLoaded', () => {
  loadAssets();
  updateUI();
});
